# parcialArreglo
